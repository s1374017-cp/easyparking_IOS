//
//  easyparkingAPPIOS_0_2Tests.swift
//  easyparkingAPPIOS_0.2Tests
//
//  Created by YE Jianping on 2025/4/6.
//

import Testing
@testable import easyparkingAPPIOS_0_2

struct easyparkingAPPIOS_0_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
