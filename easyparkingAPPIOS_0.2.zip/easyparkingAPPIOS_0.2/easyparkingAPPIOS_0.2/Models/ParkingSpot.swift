
//
//  ParkingSpot.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import Foundation
import CoreLocation
import MapKit


extension MKCoordinateRegion {
    static let hongKong = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 22.3193, longitude: 114.1694),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
}

struct ParkingSpot: Identifiable, Codable {
    let id: UUID
    var locationName: String
    var location: CLLocationCoordinate2D
    var startTime: Date
    var endTime: Date
    var price: Int
    
    // 手动实现Codable（因为CLLocationCoordinate2D不可直接Codable）
    private enum CodingKeys: String, CodingKey {
        case id, locationName, latitude, longitude, startTime, endTime, price
    }
    
    init(id: UUID = UUID(),
         locationName: String,
         location: CLLocationCoordinate2D,
         startTime: Date,
         endTime: Date,
         price: Int) {
        self.id = id
        self.locationName = locationName
        self.location = location
        self.startTime = startTime
        self.endTime = endTime
        self.price = price
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        locationName = try container.decode(String.self, forKey: .locationName)
        let latitude = try container.decode(CLLocationDegrees.self, forKey: .latitude)
        let longitude = try container.decode(CLLocationDegrees.self, forKey: .longitude)
        location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        startTime = try container.decode(Date.self, forKey: .startTime)
        endTime = try container.decode(Date.self, forKey: .endTime)
        price = try container.decode(Int.self, forKey: .price)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(locationName, forKey: .locationName)
        try container.encode(location.latitude, forKey: .latitude)
        try container.encode(location.longitude, forKey: .longitude)
        try container.encode(startTime, forKey: .startTime)
        try container.encode(endTime, forKey: .endTime)
        try container.encode(price, forKey: .price)
    }
    
    static func empty() -> Self {
        ParkingSpot(
            locationName: "",
            location: CLLocationCoordinate2D(latitude: 22.3193, longitude: 114.1694),
            startTime: Date(),
            endTime: Date().addingTimeInterval(3600),
            price: 10
        )
    }
}

// 扩展坐标
extension CLLocationCoordinate2D {
    static let hongKong = CLLocationCoordinate2D(latitude: 22.3193, longitude: 114.1694)
}

// 模拟数据
func mockSpots() -> [ParkingSpot] {
    [
        ParkingSpot(
            locationName: "Central Plaza",
            location: CLLocationCoordinate2D(latitude: 22.323, longitude: 114.168),
            startTime: Date(),
            endTime: Date().addingTimeInterval(86400),
            price: 30
        )
    ]
}
