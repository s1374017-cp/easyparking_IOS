
//
//  Untitled.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

enum UserType: String, CaseIterable {
    case regularUser = "Regular User"
    case owner = "Parking Owner"  // 使用正确的大小写
}
