//
//  easyparkingAPPIOS_0_2App.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import SwiftUI
import SwiftData // 注意：原代码使用了SwiftData框架

@main
struct easyparkingAPPIOS_0_2App: App {
    // SwiftData容器配置（如不需要数据库功能可删除）
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([Item.self])
        let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        do {
            return try ModelContainer(for: schema, configurations: [config])
        } catch {
            fatalError("数据库初始化失败: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(sharedModelContainer) // 删除此行若移除了SwiftData
        }
    }
}
