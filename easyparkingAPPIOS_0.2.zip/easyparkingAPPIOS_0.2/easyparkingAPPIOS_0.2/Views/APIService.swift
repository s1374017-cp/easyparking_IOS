//import Foundation
//import CoreLocation
//
//struct VacancyItem: Decodable {
//  let vehicle_type: String
//  let service_category: String
//  let vacancy_type: String
//  let vacancy: Int
//  let lastupdate: String
//}
//
//struct ParkingLot: Decodable, Identifiable {
//  let park_id: String
//  let name_en: String
//  let latitude: Double
//  let longitude: Double
//  let distance: Double
//  let vacancies: [VacancyItem]
//  
//  var id: String { park_id }
//}
//
//enum APIError: Error {
//  case invalidURL, requestFailed, decodingError
//}
//
//class APIService {
//  static let shared = APIService()
//  private let base = "http://127.0.0.1:5001/api"
//  
//  /// Fetch nearby parking lots
//  func fetchNearby(
//    lat: Double, lon: Double,
//    radius: Double = 1.0, limit: Int = 50,
//    completion: @escaping (Result<[ParkingLot],APIError>) -> Void
//  ) {
//    guard var comp = URLComponents(string: base + "/nearby") else {
//      completion(.failure(.invalidURL)); return
//    }
//    comp.queryItems = [
//      URLQueryItem(name: "lat", value: "\(lat)"),
//      URLQueryItem(name: "lon", value: "\(lon)"),
//      URLQueryItem(name: "radius", value: "\(radius)"),
//      URLQueryItem(name: "limit", value: "\(limit)")
//    ]
//    guard let url = comp.url else {
//      completion(.failure(.invalidURL)); return
//    }
//    
//    URLSession.shared.dataTask(with: url) { data, resp, err in
//      if let _ = err { return completion(.failure(.requestFailed)) }
//      guard let d = data else { return completion(.failure(.requestFailed)) }
//      do {
//        let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
//        completion(.success(lots))
//      } catch {
//        completion(.failure(.decodingError))
//      }
//    }.resume()
//  }
//}


//
//  APIService.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

import Foundation
import CoreLocation

// MARK: – Models

struct VacancyItem: Decodable, Identifiable {
    let id = UUID()
    let vehicle_type: String
    let service_category: String
    let vacancy_type: String
    let vacancy: Int
    let lastupdate: String
}

struct Vacancy: Codable, Identifiable {
    let id = UUID()
    let vehicle_type: String
    let service_category: String
    let vacancy_type: String
    let vacancy: Int
    let lastupdate: String
}

struct ParkingLot: Codable, Identifiable {
    let park_id: String
    let name_en: String
    let latitude: Double
    let longitude: Double
    let distance: Double
    let vacancies: [Vacancy]
    let isPrivate: Bool?
    var shareStart: String?  // 修复: 添加可选参数
    var shareEnd: String?     // 修复: 添加可选参数
    
    // 修复3: 移除name_zh参数
    var id: String { park_id }
    
    // 计算属性用于显示名称
    var displayName: String {
        name_en
    }
}

struct ParkingForecast: Decodable, Identifiable {
    let park_id: String
    let slot: Int
    let p_availability: Double
    var id: String { park_id + "_\(slot)" }
}

enum APIError: Error {
    case invalidURL, requestFailed, decodingError
}

class APIService {
    static let shared = APIService()
    private let base = "http://127.0.0.1:5001/api"

    // 查询附近停车场
    func fetchNearby(
        lat: Double, lon: Double,
        radius: Double = 1.0, limit: Int = 50,
        completion: @escaping (Result<[ParkingLot],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/nearby") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [
            URLQueryItem(name: "lat", value: "\(lat)"),
            URLQueryItem(name: "lon", value: "\(lon)"),
            URLQueryItem(name: "radius", value: "\(radius)"),
            URLQueryItem(name: "limit", value: "\(limit)")
        ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }

        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
                completion(.success(lots))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    // 模糊搜索停车场
    func search(
        query: String,
        completion: @escaping (Result<[ParkingLot],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/search") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [ URLQueryItem(name: "q", value: query) ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }
        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
                completion(.success(lots))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    // 获取可用概率预测
    func fetchForecast(
        lat: Double, lon: Double,
        radius: Double = 1.0,
        completion: @escaping (Result<[ParkingForecast],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/forecast") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [
            URLQueryItem(name: "lat", value: "\(lat)"),
            URLQueryItem(name: "lon", value: "\(lon)"),
            URLQueryItem(name: "radius", value: "\(radius)")
        ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }
        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let arr = try JSONDecoder().decode([ParkingForecast].self, from: d)
                completion(.success(arr))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    func uploadParkingInfo(spot: ParkingSpot, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: base + "/owner/upload_parking_info") else {
            return completion(.failure(APIError.invalidURL))
        }
    
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
        let payload: [String: Any] = [
            "owner_id": "example_owner_id", // Replace with actual owner ID
            "parking_info": [
                "location": spot.locationName,
                "description": "Shared parking spot",
                "latitude": spot.location.latitude,
                "longitude": spot.location.longitude
            ],
            "available_time_slots": [
                ["start": ISO8601DateFormatter().string(from: spot.startTime), "end": ISO8601DateFormatter().string(from: spot.endTime)]
            ]
        ]
    
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            return completion(.failure(error))
        }
    
        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                return completion(.failure(error))
            }
    
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                return completion(.failure(APIError.requestFailed))
            }
    
            completion(.success(()))
        }.resume()
    }
}
