//import Foundation
//import CoreLocation
//
//struct VacancyItem: Decodable {
//  let vehicle_type: String
//  let service_category: String
//  let vacancy_type: String
//  let vacancy: Int
//  let lastupdate: String
//}
//
//struct ParkingLot: Decodable, Identifiable {
//  let park_id: String
//  let name_en: String
//  let latitude: Double
//  let longitude: Double
//  let distance: Double
//  let vacancies: [VacancyItem]
//  
//  var id: String { park_id }
//}
//
//enum APIError: Error {
//  case invalidURL, requestFailed, decodingError
//}
//
//class APIService {
//  static let shared = APIService()
//  private let base = "http://127.0.0.1:5001/api"
//  
//  /// Fetch nearby parking lots
//  func fetchNearby(
//    lat: Double, lon: Double,
//    radius: Double = 1.0, limit: Int = 50,
//    completion: @escaping (Result<[ParkingLot],APIError>) -> Void
//  ) {
//    guard var comp = URLComponents(string: base + "/nearby") else {
//      completion(.failure(.invalidURL)); return
//    }
//    comp.queryItems = [
//      URLQueryItem(name: "lat", value: "\(lat)"),
//      URLQueryItem(name: "lon", value: "\(lon)"),
//      URLQueryItem(name: "radius", value: "\(radius)"),
//      URLQueryItem(name: "limit", value: "\(limit)")
//    ]
//    guard let url = comp.url else {
//      completion(.failure(.invalidURL)); return
//    }
//    
//    URLSession.shared.dataTask(with: url) { data, resp, err in
//      if let _ = err { return completion(.failure(.requestFailed)) }
//      guard let d = data else { return completion(.failure(.requestFailed)) }
//      do {
//        let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
//        completion(.success(lots))
//      } catch {
//        completion(.failure(.decodingError))
//      }
//    }.resume()
//  }
//}


//
//  APIService.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

import Foundation
import CoreLocation

// MARK: – Models

struct VacancyItem: Decodable, Identifiable {
    let id = UUID()
    let vehicle_type: String
    let service_category: String
    let vacancy_type: String
    let vacancy: Int
    let lastupdate: String
}

struct Vacancy: Codable, Identifiable {
    let id = UUID()
    let vehicle_type: String
    let service_category: String
    let vacancy_type: String
    let vacancy: Int
    let lastupdate: String
}

struct ParkingLot: Codable, Identifiable {
    let park_id: String
    let name_en: String
    let latitude: Double
    let longitude: Double
    let distance: Double
    let vacancies: [Vacancy]
    let isPrivate: Bool?
    var shareStart: String?
    var shareEnd: String?
    
    var id: String { park_id }
    
    var displayName: String {
        name_en
    }

    private enum CodingKeys: String, CodingKey {
        case park_id, name_en, latitude, longitude, distance, vacancies, isPrivate, shareStart, shareEnd
    }

    // 手动指定缺省值，保证缺字段也能成功解码
    init(
        park_id: String,
        name_en: String,
        latitude: Double,
        longitude: Double,
        distance: Double = 0.0,
        vacancies: [Vacancy] = [],
        isPrivate: Bool? = nil,
        shareStart: String? = nil,
        shareEnd: String? = nil
    ) {
        self.park_id = park_id
        self.name_en = name_en
        self.latitude = latitude
        self.longitude = longitude
        self.distance = distance
        self.vacancies = vacancies
        self.isPrivate = isPrivate
        self.shareStart = shareStart
        self.shareEnd = shareEnd
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        self.park_id = try c.decode(String.self, forKey: .park_id)
        self.name_en = try c.decode(String.self, forKey: .name_en)
        self.latitude = try c.decode(Double.self, forKey: .latitude)
        self.longitude = try c.decode(Double.self, forKey: .longitude)
        self.distance = (try? c.decode(Double.self, forKey: .distance)) ?? 0.0
        self.vacancies = (try? c.decode([Vacancy].self, forKey: .vacancies)) ?? []
        self.isPrivate = try? c.decode(Bool.self, forKey: .isPrivate)
        self.shareStart = try? c.decode(String.self, forKey: .shareStart)
        self.shareEnd = try? c.decode(String.self, forKey: .shareEnd)
    }
}

struct ParkingForecast: Decodable, Identifiable {
    let park_id: String
    let slot: Int
    let p_availability: Double
    var id: String { park_id + "_\(slot)" }
}

enum APIError: Error {
    case invalidURL, requestFailed, decodingError
}

class APIService {
    static let shared = APIService()
    private let base = "http://127.0.0.1:5001/api"

    // 新增：登录会话信息
    var authToken: String?
    var currentUserId: Int?

    // 新增：MySQL 友好日期格式
    private let mysqlDateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = TimeZone(secondsFromGMT: 0)
        f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return f
    }()

    // 查询附近停车场
    func fetchNearby(
        lat: Double, lon: Double,
        radius: Double = 1.0, limit: Int = 50,
        completion: @escaping (Result<[ParkingLot],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/nearby") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [
            URLQueryItem(name: "lat", value: "\(lat)"),
            URLQueryItem(name: "lon", value: "\(lon)"),
            URLQueryItem(name: "radius", value: "\(radius)"),
            URLQueryItem(name: "limit", value: "\(limit)")
        ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }

        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
                completion(.success(lots))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    // 模糊搜索停车场
    func search(
        query: String,
        completion: @escaping (Result<[ParkingLot],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/search") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [ URLQueryItem(name: "q", value: query) ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }
        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let lots = try JSONDecoder().decode([ParkingLot].self, from: d)
                completion(.success(lots))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    // 获取可用概率预测
    func fetchForecast(
        lat: Double, lon: Double,
        radius: Double = 1.0,
        completion: @escaping (Result<[ParkingForecast],Error>) -> Void
    ) {
        guard var comp = URLComponents(string: base + "/forecast") else {
            return completion(.failure(APIError.invalidURL))
        }
        comp.queryItems = [
            URLQueryItem(name: "lat", value: "\(lat)"),
            URLQueryItem(name: "lon", value: "\(lon)"),
            URLQueryItem(name: "radius", value: "\(radius)")
        ]
        guard let url = comp.url else {
            return completion(.failure(APIError.invalidURL))
        }
        URLSession.shared.dataTask(with: url) { data, _, err in
            if let e = err { return completion(.failure(e)) }
            guard let d = data else { return completion(.failure(APIError.requestFailed)) }
            do {
                let arr = try JSONDecoder().decode([ParkingForecast].self, from: d)
                completion(.success(arr))
            } catch {
                completion(.failure(APIError.decodingError))
            }
        }.resume()
    }

    // 預約私人車位
    func bookParking(parkingId: Int, start: Date, end: Date, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: base + "/driver/book_parking") else {
            return completion(.failure(APIError.invalidURL))
        }
        guard let driverId = currentUserId else {
            print("Booking aborted: currentUserId is nil (please login as driver)")
            return completion(.failure(APIError.requestFailed))
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            request.setValue(token, forHTTPHeaderField: "Authorization")
        }

        let payload: [String: Any] = [
            "driver_id": driverId,
            "parking_id": parkingId,
            "start_time": mysqlDateFormatter.string(from: start),
            "end_time": mysqlDateFormatter.string(from: end)
        ]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            return completion(.failure(error))
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Book failed with networking error: \(error)")
                return completion(.failure(error))
            }
            if let httpResponse = response as? HTTPURLResponse {
                let code = httpResponse.statusCode
                let body = (data.flatMap { String(data: $0, encoding: .utf8) }) ?? ""
                print("Book status: \(code)")
                print("Book response body: \(body)")
                guard (200...299).contains(code) else {
                    return completion(.failure(APIError.requestFailed))
                }
            }
            completion(.success(()))
        }.resume()
    }
    
    // 上傳/分享車位資訊（車主）
    func uploadParkingInfo(spot: ParkingSpot, completion: @escaping (Result<Void, Error>) -> Void) {
        guard let ownerId = currentUserId else {
            print("Upload aborted: currentUserId is nil (please login as owner)")
            return completion(.failure(APIError.requestFailed))
        }
        // 修正為後端實際路徑：/api/owner/upload_parking_info
        guard let url = URL(string: base + "/owner/upload_parking_info") else {
            return completion(.failure(APIError.invalidURL))
        }
        
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token = authToken {
            req.setValue(token, forHTTPHeaderField: "Authorization")
        }
        
        // 修正 payload 結構，與後端一致
        let payload: [String: Any] = [
            "owner_id": ownerId,
            "parking_info": [
                "location": spot.locationName,
                "description": "",
                "latitude": spot.location.latitude,
                "longitude": spot.location.longitude
            ],
            "available_time_slots": [
                [
                    "start": mysqlDateFormatter.string(from: spot.startTime),
                    "end": mysqlDateFormatter.string(from: spot.endTime)
                ]
            ]
        ]
        
        do {
            req.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            return completion(.failure(error))
        }
        
        URLSession.shared.dataTask(with: req) { data, resp, err in
            if let err = err {
                print("Upload failed (network error): \(err)")
                return completion(.failure(err))
            }
            if let http = resp as? HTTPURLResponse {
                let code = http.statusCode
                let body = (data.flatMap { String(data: $0, encoding: .utf8) }) ?? ""
                print("Upload status: \(code)")
                print("Upload response body: \(body)")
                guard (200...299).contains(code) else {
                    return completion(.failure(APIError.requestFailed))
                }
            }
            completion(.success(()))
        }.resume()
    }
}
