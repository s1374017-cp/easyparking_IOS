//
//  ParkingUserView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

//import SwiftUI
//
//struct ParkingUserView: View {
//    @State private var availableSpots: [ParkingSpot] = mockSpots()
//    @State private var selectedSpot: ParkingSpot?
//    
//    var body: some View {
//        NavigationStack {
//            List(availableSpots) { spot in
//                ParkingSpotCard(spot: spot)
//                    .onTapGesture { selectedSpot = spot }
//            }
//            .navigationTitle("Nearby Parking")
//            .sheet(item: $selectedSpot) { spot in
//                ReservationView(spot: spot)
//            }
//        }
//    }
//}
//
//// Reservation view
//struct ReservationView: View {
//    let spot: ParkingSpot
//    @State private var selectedHours = 1
//    
//    var body: some View {
//        VStack {
//            Text("Reserve \(spot.locationName)")
//                .font(.title)
//            
//            Stepper("\(selectedHours) hours", value: $selectedHours, in: 1...24)
//            
//            Button("Confirm Payment \(spot.price * selectedHours) yuan") {
//                // Payment logic
//            }
//            .buttonStyle(.borderedProminent)
//        }
//        .padding()
//    }
//}
//
//struct ParkingSpotCard: View {
//    let spot: ParkingSpot
//    
//    var body: some View {
//        VStack(alignment: .leading) {
//            Text(spot.locationName)
//                .font(.headline)
//            Text("Price: \(spot.price) yuan/hour")
//                .font(.subheadline)
//        }
//    }
//}    

import SwiftUI
import CoreLocation

struct ParkingUserView: View {
  @State private var spots: [ParkingLot] = []
  @State private var selectedSpot: ParkingLot?
  @State private var radius: Double = 1.0
  @State private var isLoading = false
  @State private var errorMessage: String?
  
  // For demo we use a fixed coordinate; in real app use CoreLocation
  let userLat = 22.3193
  let userLon = 114.1694
  
  var body: some View {
    NavigationStack {
      VStack {
        // radius slider
        HStack {
          Text("Radius: \(String(format:"%.1f", radius)) km")
          Slider(value: $radius, in: 0.5...5.0, step: 0.5) {
            Text("Radius")
          }
          .onChange(of: radius) { _ in fetch() }
        }
        .padding()
        
        if isLoading {
          ProgressView("Loading…")
        } else if let err = errorMessage {
          Text("Error: \(err)")
            .foregroundColor(.red)
            .padding()
        } else {
          List(spots) { lot in
            ParkingSpotCard(lot: lot)
              .onTapGesture { selectedSpot = lot }
          }
        }
      }
      .navigationTitle("Nearby Parking")
      .onAppear(perform: fetch)
      .sheet(item: $selectedSpot) { spot in
        ReservationView(spot: spot)
      }
    }
  }
  
  private func fetch() {
    isLoading = true
    errorMessage = nil
    APIService.shared.fetchNearby(lat: userLat, lon: userLon, radius: radius) { result in
      DispatchQueue.main.async {
        isLoading = false
        switch result {
          case .success(let lots): spots = lots
          case .failure(let err): errorMessage = "\(err)"
        }
      }
    }
  }
}

struct ParkingSpotCard: View {
  let lot: ParkingLot
  var body: some View {
    VStack(alignment: .leading) {
      Text(lot.name_en).font(.headline)
      Text("Distance: \(String(format:"%.2f", lot.distance)) km")
        .font(.subheadline)
      if let v = lot.vacancies.first {
        Text("Vacancy: \(v.vacancy) \(v.vacancy_type)")
          .font(.caption)
      }
    }
    .padding(.vertical, 4)
  }
}
