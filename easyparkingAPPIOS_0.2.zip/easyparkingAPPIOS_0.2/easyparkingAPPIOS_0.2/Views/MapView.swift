//
//  MapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import SwiftUI
import MapKit

struct MapView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 22.3193, longitude: 114.1694),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    
    var body: some View {
        Map(
            coordinateRegion: .constant(.hongKong),
            interactionModes: .all,
            showsUserLocation: false
        )
    }
}
