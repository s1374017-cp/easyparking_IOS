//
//  SearchView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//
//  SearchView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

import SwiftUI

struct SearchView: View {
    @State private var query = ""
    @State private var results: [ParkingLot] = []
    @State private var isLoading = false
    @State private var error: String?
    @State private var selectedLot: ParkingLot? = nil

    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    TextField("Search parking", text: $query)
                        .textFieldStyle(.roundedBorder)
                    Button("Go") { load() }
                        .buttonStyle(.borderedProminent)
                }
                .padding()

                if isLoading {
                    ProgressView("Searching…")
                } else if let e = error {
                    Text(e).foregroundColor(.red).padding()
                } else {
                    List(results) { lot in
                        Button(action: { selectedLot = lot }) {
                            VStack(alignment: .leading) {
                                Text(lot.name_en).font(.headline)
                                Text("Distance: \(lot.distance, specifier: "%.2f") km").font(.subheadline)
                            }
                        }
                    }
                    .sheet(item: $selectedLot) { lot in
                        ParkingDetailPanel(lot: lot) {
                            selectedLot = nil
                        }
                    }
                }
            }
            .navigationTitle("Find Parking")
        }
    }

    func load() {
        guard !query.isEmpty else { return }
        isLoading = true; error = nil
        APIService.shared.search(query: query) { r in
            DispatchQueue.main.async {
                isLoading = false
                switch r {
                case .success(let arr): results = arr
                case .failure(let e): error = e.localizedDescription
                }
            }
        }
    }
}
