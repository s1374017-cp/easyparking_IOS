//
//  LoginView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

//import SwiftUI
//
//struct LoginView: View {
//    @Binding var isLoggedIn: Bool
//    @State private var email = ""
//    @State private var password = ""
//    @State private var userType: UserType = .regularUser // User type state
//    
//    // User type enum
//    enum UserType: String, CaseIterable {
//        case regularUser = "Regular User"
//        case parkingSharer = "Parking Sharer"
//    }
//    
//    var body: some View {
//        ZStack {
//            // Background logo (ensure there's an "app-logo" image asset)
//            Image("app-logo")
//                .resizable()
//                .scaledToFill()
//                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
//                .opacity(0.15) // Appropriate transparency
//                .edgesIgnoringSafeArea(.all)
//            
//            // Login form
//            VStack(spacing: 20) {
//                Text("EasyParking")
//                    .font(.largeTitle)
//                    .bold()
//                    .padding(.bottom, 20)
//                
//                // Email input
//                TextField("Email", text: $email)
//                    .textFieldStyle(.roundedBorder)
//                    .autocapitalization(.none)
//                    .keyboardType(.emailAddress)
//                
//                // Password input
//                SecureField("Password", text: $password)
//                    .textFieldStyle(.roundedBorder)
//                
//                // User type selection
//                Picker("User Type", selection: $userType) {
//                    ForEach(UserType.allCases, id: \.self) { type in
//                        Text(type.rawValue).tag(type)
//                    }
//                }
//                .pickerStyle(.segmented)
//                .padding(.vertical, 10)
//                
//                // Login button
//                Button(action: login) {
//                    Text("Login")
//                        .frame(maxWidth: .infinity)
//                }
//                .buttonStyle(.borderedProminent)
//                .padding(.top, 10)
//                
//                // Test account information
//                Text("Test Account: user001@easypark.com\nPassword: password")
//                    .font(.footnote)
//                    .foregroundColor(.gray)
//            }
//            .padding(30)
//            .background(Color(.systemBackground).opacity(0.8))
//            .cornerRadius(15)
//            .shadow(radius: 10)
//            .padding(20)
//        }
//    }
//    
//    private func login() {
//        // Simple validation logic
//        if email == "user001@easypark.com" && password == "password" {
//            isLoggedIn = true
//            print("Login successful, user type: \(userType.rawValue)")
//        }
//    }
//}    


// LoginView.swift
import SwiftUI

struct LoginView: View {
    @Binding var isLoggedIn: Bool
    @Binding var userType: UserType
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("EasyParking").font(.largeTitle).bold()
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.emailAddress)
            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)
            Picker("User Type", selection: $userType) {
                ForEach(UserType.allCases, id: \ .self) { type in
                    Text(type.rawValue).tag(type)
                }
            }
            .pickerStyle(.segmented)

            Button("Login") {
                login()
            }
            .buttonStyle(.borderedProminent)
            .padding(.top)

            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.footnote)
            }
        }
        .padding()
    }

    private func login() {
        guard let url = URL(string: "http://127.0.0.1:5001/api/login") else {
            errorMessage = "Invalid server URL"
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: String] = ["username": email, "password": password]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            errorMessage = "Failed to encode login data"
            return
        }

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    errorMessage = "Login failed: \(error.localizedDescription)"
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200,
                  let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                  let user = json["user"] as? [String: Any] else {
                DispatchQueue.main.async {
                    errorMessage = "Invalid email or password"
                }
                return
            }

            DispatchQueue.main.async {
                isLoggedIn = true
                print("Welcome \(user["username"] ?? "")")
            }
        }.resume()
    }
}
