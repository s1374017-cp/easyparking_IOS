//
//  ContentView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import SwiftUI
//
//struct ContentView: View {
//    @State private var isLoggedIn = false
//    @State private var userType: UserType = .regularUser
//    
//    var body: some View {
//        ZStack {
//            // 背景图代码...
//            
//            if isLoggedIn {
//                MainTabView(isLoggedIn: $isLoggedIn,  // 新增绑定
//                            userType: $userType)       // 保持原有
//            } else {
//                LoginView(
//                    isLoggedIn: $isLoggedIn
//                    // email和password通过内部@State管理
//                )
//            }
//        }
//    }
//}

//struct ContentView: View {
//  @State private var isLoggedIn = false
//  @State private var userType: UserType = .regularUser
//
//  var body: some View {
//    if isLoggedIn {
//      MainTabView(isLoggedIn: $isLoggedIn, userType: $userType)
//    } else {
//      LoginView(isLoggedIn: $isLoggedIn)
//    }
//  }
//}

//struct ContentView: View {
//    @State private var isLoggedIn = false
//    @State private var userType: UserType = .regularUser
//
//    var body: some View {
//        if isLoggedIn {
//            MainTabView(isLoggedIn: $isLoggedIn, userType: $userType)
//        } else {
//            LoginView(isLoggedIn: $isLoggedIn, userType: $userType)
//        }
//    }
//}


struct ContentView: View {
    @State private var isLoggedIn = false
    @State private var userType: UserType = .regularUser

    var body: some View {
        if isLoggedIn {
            MainTabView(isLoggedIn: $isLoggedIn, userType: $userType)
        } else {
            LoginView(isLoggedIn: $isLoggedIn, userType: $userType)
        }
    }
}
