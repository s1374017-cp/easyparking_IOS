import SwiftUI

struct ContentView: View {
    @State private var isLoggedIn = false
    @State private var userType: UserType = .regularUser

    var body: some View {
        if isLoggedIn {
            NavigationStack {
                MainTabView(isLoggedIn: $isLoggedIn, userType: $userType)
            }
        } else {
            LoginView(isLoggedIn: $isLoggedIn, userType: $userType)
        }
    }
}
