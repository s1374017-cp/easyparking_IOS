//
//  FilterView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import SwiftUI

struct FilterView: View {
    @State private var distanceFilter: Double = 5.0
    @State private var priceFilter: Double = 20.0
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Distance Filter (km)") {
                    Slider(value: $distanceFilter, in: 1...20, step: 1)
                    Text("Distance: \(Int(distanceFilter)) km")
                }
                
                Section("Price Filter (per hour)") {
                    Slider(value: $priceFilter, in: 5...50, step: 1)
                    Text("Price: \(Int(priceFilter)) yuan")
                }
                
                Button("Apply Filters") {
                    print("Distance: \(distanceFilter), Price: \(priceFilter)")
                }
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Parking Filter")
        }
    }
}    
