//
//  NavigateView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//
//  NavigateView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

import SwiftUI
import CoreLocation

struct NavigateView: View {
    @State private var dest = ""
    @State private var lots: [ParkingLot] = []
    @State private var forecasts: [String:Double] = [:]
    @State private var error: String?

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                TextField("Enter destination (e.g. Causeway Bay)", text: $dest)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button("Search Parking") { search() }
                    .buttonStyle(.borderedProminent)

                if let e = error {
                    Text(e).foregroundColor(.red)
                }

                List(lots) { lot in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(lot.name_en).font(.headline)
                        Text("Vacancy: \(lot.vacancies.first?.vacancy ?? 0)")
                        if let p = forecasts[lot.park_id] {
                            Text("P(available)=\(p, specifier: "%.2f")")
                        }
                    }
                }
            }
            .navigationTitle("Navigate")
        }
    }

    func search() {
        CLGeocoder().geocodeAddressString(dest) { ps, err in
            guard let loc = ps?.first?.location else {
                error = "Address not found"
                return
            }
            APIService.shared.fetchNearby(lat: loc.coordinate.latitude,
                                          lon: loc.coordinate.longitude) { r in
                DispatchQueue.main.async {
                    switch r {
                    case .success(let arr):
                        lots = arr
                        // 拉取概率预测
                        APIService.shared.fetchForecast(
                            lat: loc.coordinate.latitude,
                            lon: loc.coordinate.longitude
                        ) { f in
                            DispatchQueue.main.async {
                                if case .success(let arr2) = f {
                                    forecasts = Dictionary(uniqueKeysWithValues:
                                        arr2.map { ($0.park_id, $0.p_availability) })
                                }
                            }
                        }
                    case .failure(let e):
                        error = e.localizedDescription
                    }
                }
            }
        }
    }
}
