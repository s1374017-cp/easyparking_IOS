//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//import SwiftUI
//import MapKit
//import CoreLocation
//
//// MARK: – 主视图
//struct NearbyMapView: View {
//    @StateObject private var vm = MapViewModel()
//    @State private var selectedLot: ParkingLot?
//    @State private var showDetail = false
//
//    var body: some View {
//        ZStack {
//            MapViewRepresentable(
//                annotations: vm.annotations,
//                region: $vm.region,
//                onSelect: { lot in
//                    selectedLot = lot
//                    showDetail = true
//                }
//            )
//            .edgesIgnoringSafeArea(.all)
//
//            if showDetail, let lot = selectedLot {
//                ParkingDetailPanel(lot: lot) {
//                    // TODO: 预约或其它操作
//                }
//                .transition(.move(edge: .bottom))
//            }
//        }
//        .onAppear { vm.startUpdating() }
//    }
//}
//
//// MARK: – UIViewRepresentable
//struct MapViewRepresentable: UIViewRepresentable {
//    let annotations: [AnnotatedParking]
//    @Binding var region: MKCoordinateRegion
//    var onSelect: (ParkingLot)->Void
//
//    func makeUIView(context: Context) -> MKMapView {
//        let map = MKMapView()
//        map.delegate = context.coordinator
//        map.setRegion(region, animated: false)
//        return map
//    }
//
//    func updateUIView(_ uiView: MKMapView, context: Context) {
//        uiView.removeAnnotations(uiView.annotations)
//        uiView.addAnnotations(annotations.map(\.annotation))
//        uiView.setRegion(region, animated: true)
//    }
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self, onSelect: onSelect)
//    }
//
//    class Coordinator: NSObject, MKMapViewDelegate {
//        var parent: MapViewRepresentable
//        var onSelect: (ParkingLot)->Void
//
//        init(_ parent: MapViewRepresentable, onSelect: @escaping (ParkingLot)->Void) {
//            self.parent = parent
//            self.onSelect = onSelect
//        }
//
//        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//            guard
//                let anno = view.annotation as? MKPointAnnotation,
//                let ap = parent.annotations.first(where: { $0.annotation === anno })
//            else { return }
//            onSelect(ap.lot)
//        }
//    }
//}
//
//// MARK: – 带模型的注解
//struct AnnotatedParking {
//    let lot: ParkingLot
//    let annotation: MKPointAnnotation
//}
//
//extension AnnotatedParking {
//    init(lot: ParkingLot) {
//        self.lot = lot
//        let a = MKPointAnnotation()
//        a.coordinate = CLLocationCoordinate2D(latitude: lot.latitude, longitude: lot.longitude)
//        a.title = lot.name_en
//        self.annotation = a
//    }
//}
//
//// MARK: – 视图模型
//class MapViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
//    @Published var region = MKCoordinateRegion(
//        center: CLLocationCoordinate2D(latitude: 22.3193, longitude: 114.1694),
//        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
//    )
//    @Published var annotations: [AnnotatedParking] = []
//
//    private let locMgr = CLLocationManager()
//
//    func startUpdating() {
//        locMgr.delegate = self
//        locMgr.requestWhenInUseAuthorization()
//        locMgr.startUpdatingLocation()
//    }
//
//    func locationManager(_ m: CLLocationManager, didUpdateLocations locs: [CLLocation]) {
//        guard let loc = locs.first?.coordinate else { return }
//        region.center = loc
//        // 拉取附近停车场
//        APIService.shared.fetchNearby(lat: loc.latitude, lon: loc.longitude) { res in
//            DispatchQueue.main.async {
//                if case .success(let lots) = res {
//                    self.annotations = lots.map { AnnotatedParking(lot: $0) }
//                }
//            }
//        }
//        m.stopUpdatingLocation()
//    }
//}
//
//// MARK: – 详情面板
//struct ParkingDetailPanel: View {
//    let lot: ParkingLot
//    var onAction: ()->Void
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 8) {
//            Text(lot.name_en).font(.headline)
//            ForEach(lot.vacancies) { v in
//                Text("\(v.service_category): \(v.vacancy) spots")
//            }
//            if let isP = lot.isPrivate, isP,
//               let start = lot.shareStart, let end = lot.shareEnd {
//                Text("Available: \(start) - \(end)")
//                Button("Estimate Booking") { onAction() }
//                    .buttonStyle(.bordered)
//            }
//        }
//        .padding()
//        .background(.ultraThinMaterial)
//        .cornerRadius(12)
//        .padding(.horizontal)
//        .padding(.bottom, 20)
//    }
//}


//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//import SwiftUI
//import MapKit
//import CoreLocation
//
//// MARK: - 主视图
//struct NearbyMapView: View {
//    @StateObject private var vm = MapViewModel()
//    @State private var selectedLot: ParkingLot?
//    @State private var showDetail = false
//
//    var body: some View {
//        ZStack {
//            MapViewRepresentable(
//                annotations: vm.annotations,
//                region: $vm.region,
//                onSelect: { lot in
//                    selectedLot = lot
//                    showDetail = true
//                }
//            )
//            .edgesIgnoringSafeArea(.all)
//
//            if showDetail, let lot = selectedLot {
//                ParkingDetailPanel(lot: lot) {
//                    // TODO: 预约或其它操作
//                }
//                .transition(.move(edge: .bottom))
//            }
//        }
//        .onAppear { vm.startUpdating() }
//    }
//}
//
//// MARK: - UIViewRepresentable
//struct MapViewRepresentable: UIViewRepresentable {
//    let annotations: [AnnotatedParking]
//    @Binding var region: MKCoordinateRegion
//    var onSelect: (ParkingLot)->Void
//
//    func makeUIView(context: Context) -> MKMapView {
//        let map = MKMapView()
//        map.delegate = context.coordinator
//        map.setRegion(region, animated: false)
//        return map
//    }
//
//    func updateUIView(_ uiView: MKMapView, context: Context) {
//        uiView.removeAnnotations(uiView.annotations)
//        uiView.addAnnotations(annotations.map(\.annotation))
//        uiView.setRegion(region, animated: true)
//    }
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self, onSelect: onSelect)
//    }
//
//    class Coordinator: NSObject, MKMapViewDelegate {
//        var parent: MapViewRepresentable
//        var onSelect: (ParkingLot)->Void
//
//        init(_ parent: MapViewRepresentable, onSelect: @escaping (ParkingLot)->Void) {
//            self.parent = parent
//            self.onSelect = onSelect
//        }
//
//        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//            guard
//                let anno = view.annotation as? MKPointAnnotation,
//                let ap = parent.annotations.first(where: { $0.annotation === anno })
//            else { return }
//            onSelect(ap.lot)
//        }
//    }
//}
//
//// MARK: - 带模型的注解
//struct AnnotatedParking {
//    let lot: ParkingLot
//    let annotation: MKPointAnnotation
//}
//
//extension AnnotatedParking {
//    init(lot: ParkingLot) {
//        self.lot = lot
//        let a = MKPointAnnotation()
//        a.coordinate = CLLocationCoordinate2D(latitude: lot.latitude, longitude: lot.longitude)
//        a.title = lot.name_en
//        self.annotation = a
//    }
//}
//
//// MARK: - 视图模型
//class MapViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
//    // 时代广场坐标 (铜锣湾)
//    private let timesSquareCoordinate = CLLocationCoordinate2D(latitude: 22.2783, longitude: 114.1827)
//    
//    @Published var region = MKCoordinateRegion(
//        center: CLLocationCoordinate2D(latitude: 22.2783, longitude: 114.1827),
//        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
//    )
//    @Published var annotations: [AnnotatedParking] = []
//
//    private let locMgr = CLLocationManager()
//
//    func startUpdating() {
//        // 直接使用时代广场坐标，不请求用户位置
//        fetchNearbyParkings()
//    }
//    
//    private func fetchNearbyParkings() {
//        APIService.shared.fetchNearby(lat: timesSquareCoordinate.latitude,
//                                    lon: timesSquareCoordinate.longitude) { res in
//            DispatchQueue.main.async {
//                if case .success(let lots) = res {
//                    self.annotations = lots.map { AnnotatedParking(lot: $0) }
//                }
//            }
//        }
//    }
//}
//
//// MARK: - 详情面板
//struct ParkingDetailPanel: View {
//    let lot: ParkingLot
//    var onAction: ()->Void
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 8) {
//            Text(lot.name_en).font(.headline)
//            ForEach(lot.vacancies) { v in
//                Text("\(v.service_category): \(v.vacancy) spots")
//            }
//            if let isP = lot.isPrivate, isP,
//               let start = lot.shareStart, let end = lot.shareEnd {
//                Text("Available: \(start) - \(end)")
//                Button("Estimate Booking") { onAction() }
//                    .buttonStyle(.bordered)
//            }
//        }
//        .padding()
//        .background(.ultraThinMaterial)
//        .cornerRadius(12)
//        .padding(.horizontal)
//        .padding(.bottom, 20)
//    }
//}

//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

//import SwiftUI
//import MapKit
//import CoreLocation
//
//// MARK: – Main View
//struct NearbyMapView: View {
//    @StateObject private var viewModel = MapViewModel()
//    @State private var selectedLot: ParkingLot?
//    @State private var showDetail = false
//    
//    var body: some View {
//        ZStack {
//            // Map View
//            MapViewRepresentable(
//                annotations: viewModel.annotations,
//                region: $viewModel.region,
//                onSelect: { lot in
//                    selectedLot = lot
//                    showDetail = true
//                }
//            )
//            .edgesIgnoringSafeArea(.all)
//            
//            // Parking Detail Panel
//            if showDetail, let lot = selectedLot {
//                ParkingDetailPanel(lot: lot) {
//                    // TODO: Add reservation or other actions
//                }
//                .transition(.move(edge: .bottom))
//            }
//        }
//        .onAppear {
//            viewModel.fetchNearbyParkings()
//        }
//    }
//}
//
//// MARK: – Map View Representable
//struct MapViewRepresentable: UIViewRepresentable {
//    let annotations: [AnnotatedParking]
//    @Binding var region: MKCoordinateRegion
//    var onSelect: (ParkingLot) -> Void
//    
//    func makeUIView(context: Context) -> MKMapView {
//        let mapView = MKMapView()
//        mapView.delegate = context.coordinator
//        mapView.setRegion(region, animated: false)
//        return mapView
//    }
//    
//    func updateUIView(_ uiView: MKMapView, context: Context) {
//        uiView.removeAnnotations(uiView.annotations)
//        uiView.addAnnotations(annotations.map { $0.annotation })
//        uiView.setRegion(region, animated: true)
//    }
//    
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self, onSelect: onSelect)
//    }
//    
//    class Coordinator: NSObject, MKMapViewDelegate {
//        var parent: MapViewRepresentable
//        var onSelect: (ParkingLot) -> Void
//        
//        init(_ parent: MapViewRepresentable, onSelect: @escaping (ParkingLot) -> Void) {
//            self.parent = parent
//            self.onSelect = onSelect
//        }
//        
//        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//            guard let annotation = view.annotation as? MKPointAnnotation,
//                  let parking = parent.annotations.first(where: { $0.annotation === annotation }) else {
//                return
//            }
//            onSelect(parking.lot)
//        }
//    }
//}
//
//// MARK: – Annotated Parking Model
//struct AnnotatedParking {
//    let lot: ParkingLot
//    let annotation: MKPointAnnotation
//    
//    init(lot: ParkingLot) {
//        self.lot = lot
//        let annotation = MKPointAnnotation()
//        annotation.coordinate = CLLocationCoordinate2D(
//            latitude: lot.latitude,
//            longitude: lot.longitude
//        )
//        annotation.title = lot.name_en
//        self.annotation = annotation
//    }
//}
//
//// MARK: – View Model
//class MapViewModel: NSObject, ObservableObject {
//    // Times Square, Causeway Bay coordinates (22.2783° N, 114.1827° E)
//    private let timesSquareCoordinate = CLLocationCoordinate2D(
//        latitude: 22.2783,
//        longitude: 114.1827
//    )
//    
//    @Published var region = MKCoordinateRegion(
//        center: CLLocationCoordinate2D(latitude: 22.2783, longitude: 114.1827),
//        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
//    )
//    
//    @Published var annotations: [AnnotatedParking] = []
//    
//    func fetchNearbyParkings() {
//        APIService.shared.fetchNearby(
//            lat: timesSquareCoordinate.latitude,
//            lon: timesSquareCoordinate.longitude,
//            radius: 0.5 // 0.5 km radius around Times Square
//        ) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let parkingLots):
//                    self.annotations = parkingLots.map { AnnotatedParking(lot: $0) }
//                case .failure(let error):
//                    print("Failed to fetch nearby parkings: \(error.localizedDescription)")
//                }
//            }
//        }
//    }
//}
//
//// MARK: – Parking Detail Panel
//struct ParkingDetailPanel: View {
//    let lot: ParkingLot
//    var onAction: () -> Void
//    
//    var body: some View {
//        VStack(alignment: .leading, spacing: 8) {
//            Text(lot.name_en)
//                .font(.headline)
//            
//            ForEach(lot.vacancies, id: \.id) { vacancy in
//                Text("\(vacancy.service_category): \(vacancy.vacancy) spots")
//                    .font(.subheadline)
//            }
//            
//            if let isPrivate = lot.isPrivate, isPrivate,
//               let start = lot.shareStart, let end = lot.shareEnd {
//                Text("Available: \(start) - \(end)")
//                    .font(.caption)
//                
//                Button(action: onAction) {
//                    Text("Estimate Booking")
//                }
//                .buttonStyle(.bordered)
//            }
//        }
//        .padding()
//        .background(.ultraThinMaterial)
//        .cornerRadius(12)
//        .padding(.horizontal)
//        .padding(.bottom, 20)
//    }
//}

//import SwiftUI
//import MapKit
//import CoreLocation
//
//struct NearbyMapView: View {
//    @StateObject private var viewModel = MapViewModel()
//    @State private var selectedLot: ParkingLot?
//    @State private var showDetail = false
//    
//    var body: some View {
//        ZStack {
//            // 地图视图
//            MapViewRepresentable(
//                annotations: viewModel.annotations,
//                region: $viewModel.region,
//                onSelect: { lot in
//                    selectedLot = lot
//                    showDetail = true
//                }
//            )
//            .edgesIgnoringSafeArea(.all)
//            
//            // 停车场详情面板
//            if showDetail, let lot = selectedLot {
//                ParkingDetailPanel(lot: lot) {
//                    // 预约按钮点击事件
//                    print("预约停车场: \(lot.name_en)")
//                }
//                .transition(.move(edge: .bottom))
//                .gesture(
//                    DragGesture().onEnded { value in
//                        // 下滑手势关闭详情面板
//                        if value.translation.height > 50 {
//                            showDetail = false
//                        }
//                    }
//                )
//            }
//        }
//        .onAppear {
//            viewModel.fetchNearbyParkings()
//        }
//    }
//}
//
//// MARK: - 地图视图封装
//struct MapViewRepresentable: UIViewRepresentable {
//    let annotations: [AnnotatedParking]
//    @Binding var region: MKCoordinateRegion
//    var onSelect: (ParkingLot) -> Void
//    
//    func makeUIView(context: Context) -> MKMapView {
//        let mapView = MKMapView()
//        mapView.delegate = context.coordinator
//        mapView.setRegion(region, animated: false)
//        return mapView
//    }
//    
//    func updateUIView(_ uiView: MKMapView, context: Context) {
//        uiView.removeAnnotations(uiView.annotations)
//        
//        // 添加自定义标注
//        annotations.forEach { parking in
//            let annotation = MKPointAnnotation()
//            annotation.coordinate = parking.annotation.coordinate
//            annotation.title = parking.annotation.title
//            uiView.addAnnotation(annotation)
//        }
//        
//        uiView.setRegion(region, animated: true)
//    }
//    
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self, onSelect: onSelect)
//    }
//    
//    class Coordinator: NSObject, MKMapViewDelegate {
//        var parent: MapViewRepresentable
//        var onSelect: (ParkingLot) -> Void
//        
//        init(_ parent: MapViewRepresentable, onSelect: @escaping (ParkingLot) -> Void) {
//            self.parent = parent
//            self.onSelect = onSelect
//        }
//        
//        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//            // 自定义标注视图
//            guard annotation is MKPointAnnotation else { return nil }
//            
//            let identifier = "parkingAnnotation"
//            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
//            
//            if annotationView == nil {
//                annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
//                annotationView?.canShowCallout = true
//                (annotationView as? MKMarkerAnnotationView)?.markerTintColor = .red
//            } else {
//                annotationView?.annotation = annotation
//            }
//            
//            return annotationView
//        }
//        
//        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
//            guard let annotation = view.annotation,
//                  let parking = parent.annotations.first(where: { $0.annotation.coordinate.latitude == annotation.coordinate.latitude && $0.annotation.coordinate.longitude == annotation.coordinate.longitude }) else {
//                return
//            }
//            onSelect(parking.lot)
//        }
//    }
//}
//
//// MARK: - 视图模型
//class MapViewModel: ObservableObject {
//    // 香港湾仔区域坐标
//    private let wanChaiCoordinate = CLLocationCoordinate2D(latitude: 22.2769, longitude: 114.1738)
//    
//    @Published var region = MKCoordinateRegion(
//        center: CLLocationCoordinate2D(latitude: 22.2769, longitude: 114.1738),
//        span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
//    )
//    
//    @Published var annotations: [AnnotatedParking] = []
//    
//    func fetchNearbyParkings() {
//        APIService.shared.fetchNearby(
//            lat: wanChaiCoordinate.latitude,
//            lon: wanChaiCoordinate.longitude,
//            radius: 1.0 // 1公里半径
//        ) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let parkingLots):
//                    self.annotations = parkingLots.map { AnnotatedParking(lot: $0) }
//                case .failure(let error):
//                    print("获取附近停车场失败: \(error.localizedDescription)")
//                }
//            }
//        }
//    }
//}
//
//// MARK: - 停车场详情面板
//struct ParkingDetailPanel: View {
//    let lot: ParkingLot
//    var onAction: () -> Void
//    
//    var body: some View {
//        VStack(alignment: .leading, spacing: 12) {
//            HStack {
//                Text(lot.name_en)
//                    .font(.headline)
//                    .lineLimit(1)
//                
//                Spacer()
//                
//                Button(action: {
//                    // 关闭按钮
//                    onAction()
//                }) {
//                    Image(systemName: "xmark.circle.fill")
//                        .foregroundColor(.gray)
//                }
//            }
//            
//            Divider()
//            
//            // 显示空位信息
//            ForEach(lot.vacancies, id: \.id) { vacancy in
//                HStack {
//                    Text(vacancy.service_category)
//                        .font(.subheadline)
//                    Spacer()
//                    Text("\(vacancy.vacancy) 空位")
//                        .font(.subheadline)
//                        .foregroundColor(vacancy.vacancy > 0 ? .green : .red)
//                }
//            }
//            
//            // 如果是私人停车场，显示可用时间
//            if let isPrivate = lot.isPrivate, isPrivate,
//               let start = lot.shareStart, let end = lot.shareEnd {
//                Divider()
//                Text("可用时间: \(start) - \(end)")
//                    .font(.caption)
//            }
//            
//            // 预约按钮
//            Button(action: onAction) {
//                Text("立即预约")
//                    .frame(maxWidth: .infinity)
//                    .padding(8)
//                    .background(Color.blue)
//                    .foregroundColor(.white)
//                    .cornerRadius(8)
//            }
//            .padding(.top, 8)
//        }
//        .padding()
//        .background(Color(UIColor.systemBackground))
//        .cornerRadius(12)
//        .shadow(radius: 10)
//        .padding(.horizontal, 20)
//        .padding(.bottom, 30)
//    }
//}
//
//// MARK: - 数据模型
//struct AnnotatedParking {
//    let lot: ParkingLot
//    let annotation: MKPointAnnotation
//    
//    init(lot: ParkingLot) {
//        self.lot = lot
//        let annotation = MKPointAnnotation()
//        annotation.coordinate = CLLocationCoordinate2D(
//            latitude: lot.latitude,
//            longitude: lot.longitude
//        )
//        annotation.title = lot.name_en
//        self.annotation = annotation
//    }
//}
//
//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by jianpingye on 2025/5/25.
//
//
//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YOU on 2025/5/25.
//
//
//
//  NearbyMapView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YOU on 2025/5/25.


//import SwiftUI
//import MapKit
//import CoreLocation
//
//struct NearbyMapView: View {
//    // 1. 定位管理器，用于获取用户真实位置
//    @StateObject private var locationManager = LocationManager()
//    
//    // 2. 地图区域，默认定位到铜锣湾时代广场
//    @State private var region = MKCoordinateRegion(
//        center: CLLocationCoordinate2D(latitude: 22.37283, longitude: 114.19027),
//        span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
//    )
//    
//    // 3. 储存从 API 拉到的附近停车场数组
//    @State private var lots: [ParkingLot] = []
//    
//    // 4. 被选中的停车场，用于展示详情
//    @State private var selectedLot: ParkingLot?
//    @State private var showDetail = false
//
//    var body: some View {
//        ZStack(alignment: .bottom) {
//            // MARK: - Map with annotationItems
//            Map(
//                coordinateRegion: $region,
//                interactionModes: .all,
//                showsUserLocation: true,
//                annotationItems: lots
//            ) { lot in
//                // 自定义 annotation
//                MapAnnotation(coordinate: CLLocationCoordinate2D(
//                    latitude: lot.latitude,
//                    longitude: lot.longitude
//                )) {
//                    VStack(spacing: 2) {
//                        Image(systemName: "mappin.circle.fill")
//                            .font(.title)
//                            .foregroundColor(.red)
//                            .onTapGesture {
//                                // 点击打点，弹出详情
//                                selectedLot = lot
//                                withAnimation { showDetail = true }
//                            }
//                        Text(lot.name_en)
//                            .font(.caption2)
//                            .fixedSize()
//                    }
//                }
//            }
//            .ignoresSafeArea()
//
//            // MARK: - 底部详情面板
//            if showDetail, let lot = selectedLot {
//                ParkingDetailPanel(lot: lot) {
//                    // 点击“关闭”或“立即预约”都隐藏面板
//                    withAnimation { showDetail = false }
//                }
//                .transition(.move(edge: .bottom))
//            }
//        }
//        .onReceive(locationManager.$lastLocation) { loc in
//            // 如果拿到真实位置，则以真实位置为中心并拉取附近停车场
//            guard let loc = loc else { return }
//            region.center = loc.coordinate
//            fetchNearby(at: loc.coordinate)
//        }
//        .onAppear {
//            // 首次出现时请求定位，如果用户拒绝就保留默认时代广场中心并拉取数据
//            locationManager.requestLocation()
//            fetchNearby(at: region.center)
//        }
//    }
//    
//    private func fetchNearby(at coord: CLLocationCoordinate2D) {
//        APIService.shared.fetchNearby(
//            lat: coord.latitude,
//            lon: coord.longitude,
//            radius: 1.0
//        ) { result in
//            DispatchQueue.main.async {
//                switch result {
//                case .success(let arr):
//                    lots = arr
//                case .failure(let err):
//                    print("拉取附近停车场失败：\(err)")
//                    lots = []
//                }
//            }
//        }
//    }
//}
//
//// MARK: - 定位管理器
//class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
//    @Published var lastLocation: CLLocation?
//    private let mgr = CLLocationManager()
//
//    override init() {
//        super.init()
//        mgr.delegate = self
//        mgr.desiredAccuracy = kCLLocationAccuracyBest
//    }
//
//    func requestLocation() {
//        mgr.requestWhenInUseAuthorization()
//        mgr.requestLocation()
//    }
//
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        // 只取第一条
//        lastLocation = locations.first
//    }
//
//    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        // 定位失败时可以打个日志
//        print("定位失败：\(error.localizedDescription)")
//    }
//}
//
//// MARK: - 底部详情面板
//struct ParkingDetailPanel: View {
//    let lot: ParkingLot
//    var onAction: () -> Void
//
//    var body: some View {
//        VStack(alignment: .leading, spacing: 10) {
//            HStack {
//                Text(lot.name_en)
//                    .font(.headline)
//                    .lineLimit(1)
//                Spacer()
//                // 关闭按钮
//                Button(action: onAction) {
//                    Image(systemName: "xmark.circle.fill")
//                        .foregroundColor(.gray)
//                }
//            }
//
//            Divider()
//
//            // 列出每种服务类型的空位数
//            ForEach(lot.vacancies, id: \.id) { v in
//                HStack {
//                    Text(v.service_category)
//                    Spacer()
//                    Text("\(v.vacancy) 空位")
//                        .foregroundColor(v.vacancy > 0 ? .green : .red)
//                }
//            }
//
//            // 如果是个人共享停车场，显示可用时间
//            if lot.isPrivate == true,
//               let start = lot.shareStart,
//               let end = lot.shareEnd {
//                Divider()
//                Text("可用时间: \(start) - \(end)")
//                    .font(.caption)
//            }
//
//            // 立即预约按钮
//            Button("立即预约") {
//                onAction()
//                // TODO: 这里再接后端预约 API
//            }
//            .frame(maxWidth: .infinity)
//            .padding(8)
//            .background(Color.blue)
//            .foregroundColor(.white)
//            .cornerRadius(8)
//        }
//        .padding()
//        .background(.ultraThinMaterial)
//        .cornerRadius(12)
//        .shadow(radius: 5)
//        .padding(.horizontal, 20)
//        .padding(.bottom, 30)
//    }
//}

import SwiftUI
import MapKit
import CoreLocation

struct NearbyMapView: View {
    // 1. 定位管理器
    @StateObject private var locationManager = LocationManager()

    // 2. 地图区域
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 22.37283, longitude: 114.19027),
        span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
    )

    // 3. 停车场列表（真实 + 虚拟共享）
    @State private var lots: [ParkingLot] = []

    // 4. 当前选中的停车场
    @State private var selectedLot: ParkingLot?
    @State private var showDetail = false

    var body: some View {
        ZStack(alignment: .bottom) {
            Map(
                coordinateRegion: $region,
                interactionModes: .all,
                showsUserLocation: true,
                annotationItems: lots
            ) { lot in
                MapAnnotation(coordinate: CLLocationCoordinate2D(
                    latitude: lot.latitude,
                    longitude: lot.longitude
                )) {
                    VStack(spacing: 2) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title)
                            .foregroundColor(lot.isPrivate == true ? .blue : .red)
                            .onTapGesture {
                                selectedLot = lot
                                withAnimation { showDetail = true }
                            }
                        Text(lot.name_en)
                            .font(.caption2)
                            .fixedSize()
                    }
                }
            }
            .ignoresSafeArea()

            if showDetail, let lot = selectedLot {
                NavigationLink(destination: ReservationView(spot: lot)) {
                    ParkingDetailPanel(lot: lot) {
                        withAnimation { showDetail = false }
                    }
                }
                .transition(.move(edge: .bottom))
                .buttonStyle(.plain)
            }
        }
        .onReceive(locationManager.$lastLocation) { loc in
            guard let loc = loc else { return }
            region.center = loc.coordinate
            fetchNearby(at: loc.coordinate)
        }
        .onAppear {
            locationManager.requestLocation()
            fetchNearby(at: region.center)
        }
    }

    private func fetchNearby(at coord: CLLocationCoordinate2D) {
        APIService.shared.fetchNearby(
            lat: coord.latitude,
            lon: coord.longitude,
            radius: 1.0
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let arr):
                    lots = arr + mockSharedLots()
                case .failure(let err):
                    print("拉取附近停车场失败：\(err)")
                    lots = mockSharedLots()
                }
            }
        }
    }

    /// 虚拟的个人共享停车位
    private func mockSharedLots() -> [ParkingLot] {
        return [
            ParkingLot(
                park_id: "s1",
                name_en: "共享车位 A",
                latitude: 22.3738,
                longitude: 114.1910,
                distance: 0.2,
                vacancies: [Vacancy(
                    vehicle_type: "Private",
                    service_category: "私家车",
                    vacancy_type: "共享",
                    vacancy: 1,
                    lastupdate: "2025-05-26T08:00"
                )],
                isPrivate: true,
                shareStart: "08:00",
                shareEnd: "20:00"
            ),
            ParkingLot(
                park_id: "s2",
                name_en: "共享车位 B",
                latitude: 22.3715,
                longitude: 114.1895,
                distance: 0.3,
                vacancies: [Vacancy(
                    vehicle_type: "EV",
                    service_category: "电动车",
                    vacancy_type: "共享",
                    vacancy: 2,
                    lastupdate: "2025-05-26T08:00"
                )],
                isPrivate: true,
                shareStart: "09:00",
                shareEnd: "18:00"
            )
        ]
    }
}

// MARK: - 定位管理器
class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var lastLocation: CLLocation?
    private let mgr = CLLocationManager()

    override init() {
        super.init()
        mgr.delegate = self
        mgr.desiredAccuracy = kCLLocationAccuracyBest
    }

    func requestLocation() {
        mgr.requestWhenInUseAuthorization()
        mgr.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        lastLocation = locations.first
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("定位失败：\(error.localizedDescription)")
    }
}

// MARK: - 停车详情面板
struct ParkingDetailPanel: View {
    let lot: ParkingLot
    var onAction: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(lot.name_en)
                    .font(.headline)
                Spacer()
                Button(action: onAction) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }

            Divider()

            ForEach(lot.vacancies, id: \.id) { v in
                HStack {
                    Text(v.service_category)
                    Spacer()
                    Text("\(v.vacancy) 空位")
                        .foregroundColor(v.vacancy > 0 ? .green : .red)
                }
            }

            if lot.isPrivate == true,
               let start = lot.shareStart,
               let end = lot.shareEnd {
                Divider()
                Text("可用时间: \(start) - \(end)")
                    .font(.caption)
            }

            Button("立即预约") {
                onAction()
            }
            .frame(maxWidth: .infinity)
            .padding(8)
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
        .shadow(radius: 5)
        .padding(.horizontal, 20)
        .padding(.bottom, 30)
    }
}

