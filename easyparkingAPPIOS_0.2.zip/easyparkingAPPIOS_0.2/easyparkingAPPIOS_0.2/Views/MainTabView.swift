//
//  MainTabView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

//import SwiftUI
//
//struct MainTabView: View {
//  @Binding var isLoggedIn: Bool
//  @Binding var userType: UserType
//
//  var body: some View {
//    TabView {
//      ParkingUserView()
//        .tabItem {
//          Label("Find Parking", systemImage: "car")
//        }
//
//      MapView()
//        .tabItem {
//          Label("Map", systemImage: "map")
//        }
//
//      RoutePlanningView()
//        .tabItem {
//          Label("Navigate", systemImage: "car.fill")
//        }
//
//      Button("Log Out") {
//        isLoggedIn = false
//      }
//      .tabItem {
//        Label("Logout", systemImage: "person.crop.circle.badge.xmark")
//      }
//    }
//  }
//}


import SwiftUI

struct MainTabView: View {
  @Binding var isLoggedIn: Bool
  @Binding var userType: UserType

  var body: some View {
    TabView {
      // 车主专属：我的共享车位
      if userType == .owner {
        ParkingOwnerView()
          .tabItem { Label("My Spots", systemImage: "parkingsign") }
      }
      // 普通用户：查找停车
      if userType == .regularUser {
        ParkingUserView()
          .tabItem { Label("Find Parking", systemImage: "car") }
      }
      // 地图：通用
      NearbyMapView()
        .tabItem { Label("Map", systemImage: "map") }
      // 导航：通用
      NavigateView()
        .tabItem { Label("Navigate", systemImage: "car.fill") }
      // 搜索：通用
      SearchView()
        .tabItem { Label("Search", systemImage: "magnifyingglass") }
      // 登出
      Button("Log Out") { isLoggedIn = false }
        .tabItem { Label("Logout", systemImage: "person.crop.circle.badge.xmark") }
    }
  }
}
