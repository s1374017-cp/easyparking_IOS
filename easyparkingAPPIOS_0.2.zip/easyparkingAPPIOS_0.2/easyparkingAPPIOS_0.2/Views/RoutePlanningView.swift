//
//  RoutePlanningView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

import SwiftUI
import MapKit

struct RoutePlanningView: View {
    @State private var destination = ""
    @State private var routeInfo: String?
    
    var body: some View {
        NavigationStack {
            VStack {
                TextField("Enter destination", text: $destination)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                Button("Plan Route") {
                    routeInfo = "Estimated Time: 15 minutes | Distance: 5 km"
                }
                .buttonStyle(.borderedProminent)
                
                if let info = routeInfo {
                    Text(info)
                        .padding()
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Route Planning")
        }
    }
}    
