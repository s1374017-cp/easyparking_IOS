//
//  ParkingOwnerView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/4/6.
//

//
//  ParkingOwnerView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by You on 2025/5/25.
//

import SwiftUI
import MapKit

struct ParkingOwnerView: View {
    // 已分享的停车场列表
    @State private var spots: [ParkingSpot] = []
    // 控制“分享表单”弹出
    @State private var showShareForm = false
    // 用于编辑的新 ParkingSpot，初始空
    @State private var newSpot = ParkingSpot.empty()
    // 地图区域，默认香港
    @State private var mapRegion = MKCoordinateRegion.hongKong

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // MARK: — 地图展示
                Map(
                    coordinateRegion: $mapRegion,
                    annotationItems: spots
                ) { spot in
                    MapAnnotation(coordinate: spot.location) {
                        VStack(spacing: 4) {
                            Image(systemName: "mappin.circle.fill")
                                .font(.title)
                                .foregroundColor(.blue)
                                .onTapGesture {
                                    // 点击车主自己共享的停车场
                                    print("Tapped owner spot: \(spot.locationName)")
                                    // TODO: 可以在这里做编辑、查看详情或查看预约情况
                                }
                            Text(spot.locationName)
                                .font(.caption2)
                                .fixedSize()
                        }
                    }
                }
                .frame(height: 200)
                .ignoresSafeArea(edges: .top)

                // MARK: — 列表展示
                List {
                    ForEach(spots) { spot in
                        VStack(alignment: .leading) {
                            Text(spot.locationName).font(.headline)
                            HStack {
                                Text("Price: \(spot.price) HK$/hr")
                                Spacer()
                                Text("\(formatted(date: spot.startTime)) → \(formatted(date: spot.endTime))")
                                    .font(.caption2)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                // MARK: — 分享按钮
                Button {
                    // 初始化 newSpot、region
                    newSpot = ParkingSpot.empty()
                    mapRegion.center = newSpot.location
                    showShareForm = true
                } label: {
                    Label("Share Parking", systemImage: "plus.circle.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding()
            }
            .navigationTitle("My Parking Spaces")
            // 分享表单弹出
            .sheet(isPresented: $showShareForm) {
                ShareParkingForm(spot: $newSpot, onSave: {
                    APIService.shared.uploadParkingInfo(spot: newSpot) { result in
                        switch result {
                        case .success:
                            spots.append(newSpot)
                            showShareForm = false
                        case .failure(let error):
                            print("Failed to upload parking info: \(error)")
                        }
                    }
                })
            }
        }
    }

    private func formatted(date: Date) -> String {
        let fmt = DateFormatter()
        fmt.dateStyle = .none
        fmt.timeStyle = .short
        return fmt.string(from: date)
    }
}

// MARK: — 分享表单
struct ShareParkingForm: View {
    @Binding var spot: ParkingSpot
    var onSave: () -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("Location & Address") {
                    TextField("Name or Address", text: $spot.locationName)
                    MapPicker(coordinate: $spot.location)
                        .frame(height: 200)
                        .cornerRadius(8)
                }

                Section("Availability") {
                    DatePicker("Start Time", selection: $spot.startTime, displayedComponents: .hourAndMinute)
                    DatePicker("End Time", selection: $spot.endTime, displayedComponents: .hourAndMinute)
                }

                Section("Pricing") {
                    Stepper(value: $spot.price, in: 1...500, step: 5) {
                        Text("Price: \(spot.price) yuan/hr")
                    }
                }
            }
            .navigationTitle("Share Parking")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        onSave_cancel()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        onSave()
                    }
                }
            }
        }
    }

    private func onSave_cancel() {
        // 关闭表单，不保存
        onSave()
    }
}
