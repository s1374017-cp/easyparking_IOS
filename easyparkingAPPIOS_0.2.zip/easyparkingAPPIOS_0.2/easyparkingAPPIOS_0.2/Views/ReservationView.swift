import SwiftUI
import Foundation

struct ReservationView: View {
  let spot: ParkingLot
  @State private var hours: Int = 1
  @State private var message: String?
  @State private var startTime: Date = Date()
  @State private var endTime: Date = Calendar.current.date(byAdding: .hour, value: 2, to: Date()) ?? Date()
  
  var body: some View {
    VStack(spacing: 20) {
      Text("Reserve \(spot.name_en)").font(.title)

      DatePicker("Start Time", selection: $startTime, displayedComponents: [.date, .hourAndMinute])
      DatePicker("End Time", selection: $endTime, displayedComponents: [.date, .hourAndMinute])

      Button("Confirm Reservation") {
        guard spot.isPrivate == true else {
          message = "This parking spot is not privately shared and cannot be reserved."
          return
        }
        guard let pid = Int(spot.park_id) else {
          message = "This spot is missing a valid booking ID (parking_id). Please enter from the private sharing list instead."
          return
        }
        APIService.shared.bookParking(parkingId: pid, start: startTime, end: endTime) { result in
          DispatchQueue.main.async {
            switch result {
            case .success:
              message = "Reservation successful"
            case .failure:
              message = "Reservation failed. Please ensure the time exactly matches an available slot, or try again later."
            }
          }
        }
      }
      .buttonStyle(.borderedProminent)

      if let msg = message {
        Text(msg).foregroundColor(.blue).padding(.top, 8)
      }
    }
    .padding()
  }
}
