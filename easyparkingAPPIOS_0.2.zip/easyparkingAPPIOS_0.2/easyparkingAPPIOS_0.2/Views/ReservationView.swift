//
//  ReservationView.swift
//  easyparkingAPPIOS_0.2
//
//  Created by YE Jianping on 2025/5/24.
//

import SwiftUI

struct ReservationView: View {
  let spot: ParkingLot
  @State private var hours: Int = 1
  @State private var message: String?
  
  var body: some View {
    VStack(spacing: 20) {
      Text("Reserve \(spot.name_en)").font(.title)
      
      Stepper("\(hours) hour(s)", value: $hours, in: 1...24)
      
      Button("Confirm Payment") {
        // TODO: call your /api/reserve endpoint when available
        message = "Reserved \(spot.name_en) for \(hours)h (stub)"
      }
      .buttonStyle(.borderedProminent)
      
      if let msg = message {
        Text(msg).foregroundColor(.green).padding()
      }
    }
    .padding()
  }
}
